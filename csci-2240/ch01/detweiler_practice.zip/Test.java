/*
 * Brian Detweiler
 * Excercise 1-4
 * CSCI 2830
 * Java Programming
 * Azamat Mametjanov 
 */

public class Test
{
     public static void main(String[] args)
     {
          System.out.println("VIM Test");
     }
}
