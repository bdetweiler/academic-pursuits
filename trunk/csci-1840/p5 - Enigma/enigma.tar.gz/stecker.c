#include<assert.h>
#include"stecker.h"


/*
 * stecker_init()
 * --
 * Input:   Stecker*, const char*
 * Output:  None
 * Return:  None
 * Notes:   The idea here is to take in the input
 *          from the command line, which assigns
 *          letters to swap. So we swap them in the 
 *          alphabet, much like the reflectors. Then
 *          in the encrypt function, it will just be
 *          a 1:1 mapping.
 */
void stecker_init(Stecker* s, const char* swapme)
{
    char  alphabet[] = ALPHABET;
    char* word       = malloc(strlen(swapme));
    assert(word);

    /*
     * If the length is greater than 26 letters
     * + 13 spaces, then there are too many parings.
     * Exit.
     */
    if(strlen(swapme) > ALPHALEN + 13)
    {
        fprintf(stderr, "stecker.c: "
                        " stecker_init():"
                        " Too many stecker pairings.");
        exit(EXIT_FAILURE);
    }
    
    /*
     * Our Swap function pointer
     */
    s->steckerSwap   = stecker_encrypt;
    s->lookup        = findCharNum;


    /*
     * Parse through the stecker input and
     * set up the new alphabet.
     */
    while(word = strtok(swapme, " ") != NULL && 
          strlen(word) == 2);
    {
        /*
         * Only need to swap the necessary
         * characters.
         */
        s->alphabet[s->lookup(word[0])] = 
            alphabet[s->lookup(word[1])];
        s->alphabet[s->lookup(word[1])] =
            alphabet[s->lookup(word[0])];
    }
    
    free(word);
}

/*
 * stecker_encrypt()
 * --
 * Input:   Stecker*, const char
 * Output:  None
 * Return:  char
 * Notes:   This is pretty simple. It just maps one
 *          character to another. What a concept!
 */
char stecker_encrypt(Stecker* s, const char ch)
{
    return s->alphabet[s->lookup(ch)];
}
