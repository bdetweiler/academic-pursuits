/*
 * Enigma v 2.0
 * --
 * main.c
 * by Brian Detweiler
 */

#include<string.h>
#include<ctype.h>
#include<unistd.h>
#include<stdio.h>
#include<stdio_ext.h>
#include<stdlib.h>
#include<assert.h>

// #include"enigma.h"
#include"spindle.h"

#define SPNDLSIZE 3 
#define KEYSIZE   3
#define LEFT      1 
#define MIDDLE    2 
#define RIGHT     3

// debugging shit
#define BUG   0     // Something greater than 1 to debug
#define DEBUG 1
#define TRACEF(x)		if ( DEBUG >= (x) )

int   rtoi(const char*);
char* itor(const int);
char** parse(char *);

/*
 * We take the initial rotor position and set that.
 * Then we take the key given and encrypt it with the
 * initial rotor position. Then we reset the positions
 * to the encrypted key. Then we encrypt the message
 * with the new key.
 */
int main(int argc, char** argv)
{
    // char  n;
    // int   i;
    char  rotor1[SPNDLSIZE + 1];
    char  rotor2[SPNDLSIZE + 1];
    char  rotor3[SPNDLSIZE + 1];
    // char  input[ SPNDLSIZE + 1];
    // char  buf[   BUFSIZ]; //  = {1, 2, 3};

    // The user's settings
    char  reflectorType;             // = 'B';
    int   rotorOrder[  SPNDLSIZE];   // = {1, 2, 3};
    char  initRotorPos[KEYSIZE + 1]; // = "AAA";
    char  key[         KEYSIZE + 1]; // = "AAA";

    // The user's message
    char  message[     BUFSIZ];      // = "TESTING";
    char  encryptedMsg[BUFSIZ];
    char  settings[    BUFSIZ];
    char* tok;
    int   counter = 0;
    
    // encryptedMsg = malloc(strlen(message) + 1);
    // assert(encryptedMsg);

    /* 
     * <ENIGMA>
     */
    Stecker   stecker;
    Rotor     left;
    Rotor     middle;
    Rotor     right;
    Reflector ref;
    Spindle   spindle;
    /* 
     * </ENIGMA>
     */



    /*
     * <SETTINGS> 
     */
    printf("Enter Enigma's configuration, key, and message:\n"); 
    printf("Example:\n"
           "B | I II III | ABC | AB CD EF GH IJ KL MN OP QR ST UV WX YZ\n"
           "AAA AAA\n"
           "THISX ISXAT EST\n");

    fgets(settings, BUFSIZ - 1, stdin);
    /* 
     * Rotors
     */
    scanf("%3s", rotor1);
    scanf("%3s", rotor2);
    scanf("%3s", rotor3);
    
    /*
     * Initial window position
     */
    scanf("%3s", initRotorPos);
    
    /*
     * Initial window position
     */
    scanf("%3s", key);
    /*
     * Message
     */ 
    /*
     * while(read(0, buf, BUFSIZ) != EOF)
     * {
     *      strncat(
     */

    while(fgets(message, BUFSIZ, stdin) != NULL)
    {;;;}
    
    /*
    for(i = 0; n != EOF; ++i)
    {
        n = getc(stdin); 
printf("message = %s\n", message);
        message[i] = n;
    }
    */ 
printf("1\n");
    /* 
     * Rotor order
     */
    rotorOrder[0] = rtoi(rotor1);
    rotorOrder[1] = rtoi(rotor2);
    rotorOrder[2] = rtoi(rotor3);
printf("2\n");
    
    /*
     * <ENIGMA>
     */
    rotor_init(&left,   rotorOrder[0], initRotorPos[0], LEFT);
    rotor_init(&middle, rotorOrder[1], initRotorPos[1], MIDDLE);
    rotor_init(&right,  rotorOrder[2], initRotorPos[2], RIGHT);

printf("3\n");

    reflector_init(&ref, reflectorType);

printf("4\n");
    spindle_init(&spindle);

printf("5\n");
    spindle.addReflector(&spindle, &ref);

printf("6\n");
    spindle.addRotor(&spindle, &left);
    spindle.addRotor(&spindle, &middle);
    spindle.addRotor(&spindle, &right);
    
printf("7\n");
    strncpy(key, 
                spindle.encrypt(&spindle, key), 
                    KEYSIZE + 1);
    /*
     * strncpy does't null-terminate
     */
    key[3] = '\0';
    
printf("8\n");
    /*
     * Now key is the newly encrypted key. Reset
     * the rotors to that key. Change the offsets 
     * of the rotors based on the keys.
     */
    spindle.left.newOffset(  &(spindle.left),   key[0]);
    spindle.middle.newOffset(&(spindle.middle), key[1]);
    spindle.right.newOffset( &(spindle.right),  key[2]);
    // </ENIGMA>
    
printf("9\n");
    strncpy(encryptedMsg, 
                spindle.encrypt(&spindle, message), 
                    strlen(message) + 1);
printf("10\n");
    /*
     * Print out all the stats and the 
     * encrypted message.
     */
    printf("reflector is '%c'\n", spindle.ref.reflectorType);
    printf("rotor is '%s'\n", itor(spindle.left.rotorNum));
    printf("rotor is '%s'\n", itor(spindle.middle.rotorNum));
    printf("rotor is '%s'\n", itor(spindle.right.rotorNum));
    printf("initial window position is '%c%c%c'\n", initRotorPos[0], 
                initRotorPos[1], initRotorPos[2]);
    printf("encrypted message key is '%c%c%c'\n", initRotorPos[0], 
                initRotorPos[1], initRotorPos[2]);
    printf("decrypted message key is '%c%c%c'\n", key[0], 
                key[1], key[2]);
    printf("Encrypted Message: %s\n", encryptedMsg);
    return 0;
#if 0
    Enigma e;

    enigma_init(&e, &rotorOrder, &key, reflectorType);

    while((n = read(0, buf, BUFSIZ)) > 0)
        strncat(message, buf, BUFSIZ);

    encryptedMsg = (char*)malloc(strlen(message));

    // ENCRYPT
    encryptedMsg = e.encrypt(&e, message);
    // write(1, message, n);
    // {;;;} 

    // message = realloc(message, strlen(message) + SIZE);

    // Make sure arr was allocated ok
    // assert(message);


    // printf("%s\n", spindle.encrypt(&spindle, message));
#endif
}

char** parse(char* parseMe)
{
    char*  tok;
    char*  tok2;
    char** rval;
    int    i;

    // The user's settings
    char  rotor1[SPNDLSIZE + 1];
    char  rotor2[SPNDLSIZE + 1];
    char  rotor3[SPNDLSIZE + 1];

    char  reflectorType;             
    int   rotorOrder[  SPNDLSIZE];  
    char  initRotorPos[KEYSIZE + 1]; 
    // char  key[         KEYSIZE + 1];


    tok = malloc(strlen(parseMe));

    for(counter = 0; (tok = strtok(parseMe, "|"); ++counter))
    {
        switch(counter)
        {
            /*
             * Reflector
             */
            case 0:
                /*
                 * First off, if it is more than 1 character, exit.
                 */
                if(strlen(tok) > 1)
                {
                    fprintf(stderr, "main.c: "
                                    "main(): "
                                    "Reflector must be one letter");
                    exit(EXIT_FAILURE);
                }

                if(     strchr(tok, 'B'))
                    reflectorType = 'B';
                else if(strchr(tok, 'C'))
                    reflectorType = 'C';
                else if(strchr(tok, 'X'))
                    reflectorType = 'X';
                else
                {
                    /*
                     * They entered an incorrect rotor type.
                     */
                    fprintf(stderr, "main.c: "
                                    "main(): "
                                    "Wrong reflector type. "
                                    "Candidates are: B, C, X");
                    exit(EXIT_FAILURE);
                }
                break;
            case 1:
                for(i = 0; tok2 = strtok(tok, " "); ++i)
                {
                    if(strchr(tok2, 'V'))
                    {
                        /*
                         * Rotor IV
                         */
                        if(strchr(tok2, 'I'))
                        {
                            if(i == 0)
                                strncpy(rotor1, "IV", SPNDLSIZE);
                            else if(i == 1)
                                strncpy(rotor2, "IV", SPNDLSIZE);
                            else if(i == 2)
                                strncpy(rotor3, "IV", SPNDLSIZE);
                        }
                        /*
                         * Rotor V
                         */
                        else
                        {
                            if(i == 0)
                                strncpy(rotor1, "V", SPNDLSIZE);
                            else if(i == 1)
                                strncpy(rotor2, "V", SPNDLSIZE);
                            else if(i == 2)
                                strncpy(rotor3, "V", SPNDLSIZE);
                        }
                    } // If V or IV
                    else if(strchr(tok2, 'I'))
                    {
                        if(i == 0)
                        {
                            if(strlen(tok2) == 1)
                                strncpy(rotor1, "I", SPNDLSIZE);
                            if(strlen(tok2) == 1)
                                rotor1[2] = 'I';
                            if(strlen(tok2) > 3)
                            {
                                fprintf(stderr, 
                                        

                        else if(i == 1)
                            rotor2[0] = 'I';
                        else if(i == 0)
                            rotor3[0] = 'I';

                        if(strlen(tok2) == 1)
                        {
                            if(i == 0)
                            {
                                rotor1[0] = 'I';
                                rotor1[1] = '\0';
                            }
                            else if(i == 1)
                            {
                                rotor2[0] = 'I';
                                rotor2[1] = '\0';
                            }
                            else if(i == 0)
                            {
                                rotor3[0] = 'V';
                                rotor3[1] = '\0';
                            }
                    }

                }



                            
                            

                /* 
                 * TODO: Parse through rotor assignments.
                 */
                break;
            case 2: 
                /*
                 * TODO: Parse through ring settings
                 */
                break;
            case 3:
                /*
                 * TODO: Trim stecker settings and send them into
                 *       stecker.c
                 */
                break;

            default:
                fprintf(stderr, "main.c: main(): Too many arguments.");
                exit(EXIT_FAILURE);
                break;
        }
    }
    /* 
     * TODO: Need to parse the line above. 
     * Idea: Do a while() and parse each character individually
     *       ala the server. Throw away pipe symbols |, and move
     *       to the next thing we need to save. When we hit a return,
     *       then we can go on to the keys and message.
     */



}

/*
 * rtoi (Roman To Integer)
 * --
 * Input:  A char*
 * Output: none
 * Return: The integer equivalent of the roman numeral
 * Notes:  Send this function a string of roman numerals
 *         and it will send back the integer equivalent.
 *         Right now, it is not a full-fledged rtoi().
 *         It just gives us what we want.
 */
int rtoi(const char* roman)
{
    int rval;

    if(strcasecmp(     roman, "I")   == 0)
        rval = 1;
    else if(strcasecmp(roman, "II")  == 0)
        rval = 2;
    else if(strcasecmp(roman, "III") == 0)
        rval = 3;
    else if(strcasecmp(roman, "IV")  == 0)
        rval = 4;
    else if(strcasecmp(roman, "V")   == 0)
        rval = 5;
    else
    {
        fprintf(stderr, "main.c: rtoi(): Incorrect roman numeral type.\n");
        exit(EXIT_FAILURE);
    }

    return rval;
}
    
char* itor(const int rotorNum)
{
    char* rval;

    if(rotorNum == 1)
        rval = "I"; 
    if(rotorNum == 2)
        rval = "II"; 
    if(rotorNum == 3)
        rval = "III"; 
    if(rotorNum == 4)
        rval = "IV"; 
    if(rotorNum == 5)
        rval = "IV"; 
    return rval;
}
