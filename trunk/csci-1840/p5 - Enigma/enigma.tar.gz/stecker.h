#include"rotor.h"

/*
 * Maybe try an #ifndef ROTOR_H or something
 */
#define ALPHABET "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
#define ALPHALEN 26

typedef struct stecker
{
    /*
     * The alphabet of mappings.
     */
    char alphabet[] = ALPHABET;

    (char)(*steckerSwap)(struct stecker*, const char);
    /*
     * This is from rotor.h
     */
    (int) (*lookup)     (const char);
}Stecker;


void stecker_init(   Stecker*, const char*);
char stecker_encrypt(Stecker*, const char);
